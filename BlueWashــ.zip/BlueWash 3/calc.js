
function submitMsg(){
    var email = document.getElementById("email").value;
    var msg   = document.getElementById("message").value;

    if(email == "" && msg == ""){
        alert("Please fill your Email and the message ");
    }else{
       alert("Your message has been received succesfully !")  
    }
   
}

function remind(){  
    
    var name= document.getElementById("Name").value;
    var phone= document.getElementById("Phone").value;
    var carModel = document.getElementById("suv").checked;
    var carModel2 = document.getElementById("sedan").checked;


    if ( name == ""){
     window.alert("Fill your name please!");
    }
    if ( phone == ""){
       alert("Fill your phone please!");
    }
    
    if( name !="" && phone != ""){
        if ( carModel === true){
            wind();
        }else if( carModel2 === true){
            wind();
        }else{
            window.alert("please choose your car model !");
    
        }
    } 

  function wind (){
 
  if(carModel){
        const suvPrice = 58;
           return confirm( "The total price is " + suvPrice + " based on your car model, Are you sure you want to submit?" );  
    }    else if(carModel2){
        const sedanPrice = 75;
        return confirm( "The total price is " + sedanPrice + " based on your car model, Are you sure you want to submit?" );  
    }
    
       
        }
      }