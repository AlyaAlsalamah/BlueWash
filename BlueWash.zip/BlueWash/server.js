const express = require("express");
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({extended: true}));



mongoose.connect("mongodb+srv://Nada_Alzahrani:Allahakbr0$@cluster0.iiapnk9.mongodb.net/notesDB",{useNewUrlParser:true},{uswUbifiedTopology:true})

//
const notesSchema ={
    Name:String,
    Phone:String,
    Email:String,
    Message:String
}


const Note =mongoose.model("Note",notesSchema);

app.get("/Reservation.html", (req, res)=>{
    // res.send('<p>home page</p>');
    res.sendFile(__dirname + "/Reservation.html");

 }); 

app.get("/HomePage.html", (req, res)=>{
    // res.send('<p>home page</p>');
    res.sendFile(__dirname + "/HomePage.html");
 });

 app.get("/Contact.html", (req, res)=>{
   // res.send('<p>home page</p>');
   res.sendFile(__dirname+"/Contact.html");
});

   /*
    if("/"){
     res.sendFile(__dirname+"/Contact.html");
    }

})
*/
app.post("/",function(req,res){
    let newNote =new Note({
        Name: req.body.name,
        Phone: req.body.phone,
        Email: req.body.email,
        Message: req.body.message
    });
    newNote.save();
   
})


app.listen(3000, function(){
    console.log("server running!!");
})
